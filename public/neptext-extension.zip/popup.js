// NepText Popup Logic
const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

let mode = "sentiment";
const input = $("#input");
const resultArea = $("#result-area");
const loading = $("#loading");
const analyzeBtn = $("#analyze-btn");
const btnLabel = $("#btn-label");
const statusEl = $("#status");
const apiUrlInput = $("#api-url");

// Load saved API URL
chrome.storage.local.get(["apiBaseUrl", "selectedText"], (data) => {
  apiUrlInput.value = data.apiBaseUrl || "http://localhost:8000";
  if (data.selectedText) {
    input.value = data.selectedText;
    chrome.storage.local.remove("selectedText");
  }
});

// Save API URL on change
apiUrlInput.addEventListener("change", () => {
  chrome.storage.local.set({ apiBaseUrl: apiUrlInput.value.trim() });
});

// Tab switching
$$(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    $$(".tab").forEach((t) => t.classList.remove("active"));
    tab.classList.add("active");
    mode = tab.dataset.mode;
    resultArea.innerHTML = "";
    updateBtnLabel();
  });
});

function updateBtnLabel() {
  const labels = { sentiment: "Analyze", spell: "Check", predict: "Suggest", toxicity: "Analyze" };
  btnLabel.textContent = labels[mode] || "Analyze";
}

// Copy
$("#copy-btn").addEventListener("click", () => {
  navigator.clipboard.writeText(input.value);
});

// Analyze
analyzeBtn.addEventListener("click", async () => {
  const text = input.value.trim();
  if (!text) return;

  const endpoints = {
    sentiment: "/api/sentiment",
    spell: "/api/spell-check",
    predict: "/api/predict",
    toxicity: "/api/toxicity",
  };

  loading.style.display = "flex";
  resultArea.innerHTML = "";
  analyzeBtn.disabled = true;

  chrome.runtime.sendMessage(
    { type: "API_CALL", endpoint: endpoints[mode], body: { text } },
    (response) => {
      loading.style.display = "none";
      analyzeBtn.disabled = false;

      if (response && response.success) {
        statusEl.textContent = "Live";
        statusEl.classList.add("live");
        renderResult(response.data);
      } else {
        statusEl.textContent = "Offline";
        statusEl.classList.remove("live");
        // Demo fallback
        renderDemoResult(text);
      }
    }
  );
});

function renderResult(data) {
  switch (mode) {
    case "sentiment":
      renderSentiment(data);
      break;
    case "spell":
      renderSpellCheck(data);
      break;
    case "predict":
      renderPredictions(data);
      break;
    case "toxicity":
      renderToxicity(data);
      break;
  }
}

function renderDemoResult(text) {
  switch (mode) {
    case "sentiment":
      renderSentiment({
        label: "बिनम्र सामान्य भाव",
        score: 0.78,
        explanation: "टिप्पणीले मैत्रीपूर्ण स्वर र सामान्य कल्याण लाई ब्यक्त गर्छ।",
      });
      break;
    case "spell":
      renderSpellCheck({
        original: text,
        corrected: "के गर्दै हुनुहुन्छ? म आशा गर्छु हजुर को खबर ठिकै छ होला",
        corrections: [
          { word: "k", suggestion: "के" },
          { word: "gardai", suggestion: "गर्दै" },
          { word: "hunuhunxa", suggestion: "हुनुहुन्छ" },
        ],
      });
      break;
    case "predict":
      renderPredictions({ suggestions: ["सन्चो", "ठिक", "खुसी", "बिरामी", "व्यस्त"] });
      break;
    case "toxicity":
      renderToxicity({
        label: "Non-toxic",
        score: 0.12,
        categories: [
          { name: "Hate", score: 0.05 },
          { name: "Threat", score: 0.02 },
          { name: "Insult", score: 0.15 },
          { name: "Obscene", score: 0.08 },
        ],
      });
      break;
  }
}

function renderSentiment(data) {
  const emoji = data.score >= 0.7 ? "😊" : data.score >= 0.4 ? "😐" : "😠";
  resultArea.innerHTML = `
    <div class="result">
      <div class="result-header">
        <span class="result-label">Sentiment</span>
        <button class="clear-btn" onclick="this.closest('.result').remove()">Clear</button>
      </div>
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:6px">
        <span style="font-size:18px">${emoji}</span>
        <span class="badge">${data.label}</span>
        <span style="margin-left:auto;font-size:12px;font-weight:600">${Math.round(data.score * 100)}%</span>
      </div>
      <div class="score-bar"><div class="score-bar-fill" style="width:${data.score * 100}%"></div></div>
      <p style="font-size:12px;color:var(--muted);line-height:1.5">${data.explanation}</p>
    </div>`;
}

function renderSpellCheck(data) {
  const corrections = data.corrections
    .map((c) => `<div class="correction"><span class="old">${c.word}</span><span class="arrow">→</span><span class="new">${c.suggestion}</span></div>`)
    .join("");

  resultArea.innerHTML = `
    <div class="result">
      <div class="result-header">
        <span class="result-label">Spell Check</span>
        <button class="clear-btn" onclick="this.closest('.result').remove()">Clear</button>
      </div>
      ${data.corrections.length === 0
        ? '<p style="color:var(--green);font-size:12px">✅ No errors found!</p>'
        : `${corrections}
           <p style="font-size:12px;padding:6px;border:1px solid var(--border);border-radius:6px;margin-top:6px">${data.corrected}</p>
           <button class="apply-btn" id="apply-corrections">Apply Corrections</button>`
      }
    </div>`;

  const applyBtn = document.getElementById("apply-corrections");
  if (applyBtn) {
    applyBtn.addEventListener("click", () => {
      input.value = data.corrected;
      resultArea.innerHTML = "";
    });
  }
}

function renderPredictions(data) {
  const chips = data.suggestions
    .map((s) => `<button class="pred-chip" data-word="${s}">${s}</button>`)
    .join("");

  resultArea.innerHTML = `
    <div class="result">
      <div class="result-header">
        <span class="result-label">Predictions</span>
        <button class="clear-btn" onclick="this.closest('.result').remove()">Clear</button>
      </div>
      <div class="predictions">${chips}</div>
    </div>`;

  resultArea.querySelectorAll(".pred-chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      const word = chip.dataset.word;
      input.value = input.value.endsWith(" ") ? input.value + word : input.value + " " + word;
      resultArea.innerHTML = "";
      input.focus();
    });
  });
}

function renderToxicity(data) {
  const emoji = data.score < 0.3 ? "✅" : data.score < 0.6 ? "⚠️" : "🚫";
  const cats = data.categories
    .map((c) => `
      <div class="cat-row">
        <span class="cat-name">${c.name}</span>
        <div class="cat-bar"><div class="cat-bar-fill" style="width:${c.score * 100}%"></div></div>
        <span class="cat-val">${Math.round(c.score * 100)}%</span>
      </div>`)
    .join("");

  resultArea.innerHTML = `
    <div class="result">
      <div class="result-header">
        <span class="result-label">Toxicity</span>
        <button class="clear-btn" onclick="this.closest('.result').remove()">Clear</button>
      </div>
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px">
        <span style="font-size:16px">${emoji}</span>
        <span style="font-size:13px;font-weight:500">${data.label}</span>
        <span style="margin-left:auto;font-size:11px;color:var(--muted)">${Math.round(data.score * 100)}% toxic</span>
      </div>
      ${cats}
    </div>`;
}

// Listen for selected text from background
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "SELECTED_TEXT" && msg.text) {
    input.value = msg.text;
  }
});
